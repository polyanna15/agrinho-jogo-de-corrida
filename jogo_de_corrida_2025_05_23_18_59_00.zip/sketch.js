// Variáveis do jogador (nosso "carro")
let jogadorX;
let jogadorY;
let jogadorLargura = 50;
let jogadorAltura = 50;
let velocidadeJogador = 5;

// Variáveis dos obstáculos
let obstaculos = []; // Um array para guardar todos os obstáculos
let velocidadeObstaculo = 3;
let intervaloObstaculo = 100; // Tempo em frames para gerar um novo obstáculo
let ultimoObstaculoTempo = 0;

// Variáveis do jogo
let pontuacao = 0;
let jogoAcabou = false;

function setup() {
  createCanvas(400, 600); // Tela vertical para a corrida
  
  // Posição inicial do jogador
  jogadorX = width / 2 - jogadorLargura / 2;
  jogadorY = height - jogadorAltura - 30; // Perto da parte inferior da tela
}

function draw() {
  background(50, 150, 200); // Fundo azul escuro para a "estrada"
  
  if (!jogoAcabou) {
    // Atualiza e desenha o jogador
    atualizarJogador();
    desenharJogador();

    // Gera, atualiza e desenha obstáculos
    gerarObstaculos();
    atualizarObstaculos();
    desenharObstaculos();

    // Checa colisões
    checarColisoes();

    // Atualiza e exibe a pontuação
    pontuacao++;
    fill(255); // Cor branca para o texto
    textSize(24);
    textAlign(LEFT, TOP);
    text('Pontuação: ' + floor(pontuacao / 60), 10, 10); // Pontuação a cada segundo (aprox.)
  } else {
    // Tela de "Fim de Jogo"
    fill(255);
    textSize(48);
    textAlign(CENTER, CENTER);
    text('FIM DE JOGO!', width / 2, height / 2 - 30);
    textSize(24);
    text('Pontuação Final: ' + floor(pontuacao / 60), width / 2, height / 2 + 20);
    textSize(18);
    text('Pressione R para Reiniciar', width / 2, height / 2 + 70);
  }
}

function atualizarJogador() {
  // Movimento com as setas do teclado
  if (keyIsDown(LEFT_ARROW)) {
    jogadorX -= velocidadeJogador;
  }
  if (keyIsDown(RIGHT_ARROW)) {
    jogadorX += velocidadeJogador;
  }

  // Limita o jogador dentro da tela
  jogadorX = constrain(jogadorX, 0, width - jogadorLargura);
}

function desenharJogador() {
  fill(255, 0, 0); // Carro vermelho
  rect(jogadorX, jogadorY, jogadorLargura, jogadorAltura);
}

function gerarObstaculos() {
  if (frameCount - ultimoObstaculoTempo > intervaloObstaculo) {
    let obstaculoLargura = random(30, 80);
    let obstaculoAltura = random(30, 80);
    let obstaculoX = random(0, width - obstaculoLargura);
    let obstaculoY = -obstaculoAltura; // Começa acima da tela
    obstaculos.push({ x: obstaculoX, y: obstaculoY, w: obstaculoLargura, h: obstaculoAltura });
    ultimoObstaculoTempo = frameCount;
  }
}

function atualizarObstaculos() {
  for (let i = obstaculos.length - 1; i >= 0; i--) {
    obstaculos[i].y += velocidadeObstaculo;

    // Remove obstáculos que saíram da tela
    if (obstaculos[i].y > height) {
      obstaculos.splice(i, 1); // Remove 1 elemento a partir da posição i
    }
  }
}

function desenharObstaculos() {
  fill(0, 0, 255); // Obstáculos azuis
  for (let obstaculo of obstaculos) {
    rect(obstaculo.x, obstaculo.y, obstaculo.w, obstaculo.h);
  }
}

function checarColisoes() {
  for (let obstaculo of obstaculos) {
    // Checa se os retângulos se sobrepõem
    if (
      jogadorX < obstaculo.x + obstaculo.w &&
      jogadorX + jogadorLargura > obstaculo.x &&
      jogadorY < obstaculo.y + obstaculo.h &&
      jogadorY + jogadorAltura > obstaculo.y
    ) {
      jogoAcabou = true; // Colisão!
    }
  }
}

function keyPressed() {
  if (jogoAcabou && key === 'r' || key === 'R') {
    // Reinicia o jogo
    jogoAcabou = false;
    pontuacao = 0;
    obstaculos = []; // Limpa os obstáculos
    jogadorX = width / 2 - jogadorLargura / 2; // Reseta posição do jogador
  }
}